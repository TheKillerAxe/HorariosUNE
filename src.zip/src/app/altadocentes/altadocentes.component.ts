import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { Router } from "@angular/router";
import { Usuario } from '../database/database';


@Component({
  selector: 'app-altadocentes',
  templateUrl: './altadocentes.component.html',
  styleUrls: ['./altadocentes.component.css']
})
export class AltadocentesComponent implements OnInit {

  Usuario : Usuario = new Usuario();

  constructor(public router: Router) { }

  ngOnInit(): void {
  }

  guardar(){
    Swal.fire({
      title: 'Estás seguro de subir este archivo?',
      showDenyButton: true,
      confirmButtonText: 'Subir',
      denyButtonText: `Cancelar`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('Archivo  Subido!', '', 'success')
      } else if (result.isDenied) {
        Swal.fire('Archivo no Subido', '', 'error')
      }
    })
  }

subirdocente(){
  Swal.fire({
    icon: 'success',
    title: 'Exito',
    text: 'Usuario registrado con exito en el sistema',
    showConfirmButton: false,
    timer: 1500
  }).then(() => {
    this.router.navigate(['./inicio'], { state: this.Usuario });
})
}

}
